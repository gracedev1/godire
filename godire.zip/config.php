<?php

$conn = mysqli_connect('localhost','3306','','godireco_wallstant') or die('connection failed');

?>